
// This component is no longer actively used as equipment details are
// now displayed on a dedicated page (EquipmentDetailPage.tsx).
// It's kept here for reference or potential future use if a modal view is needed again.
// To fully remove, delete this file and update any remaining imports (though there should be none).
import React from 'react';
// Minimal content to signify it's deprecated in current flow.
const EquipmentDetailModal: React.FC = () => null;
export default EquipmentDetailModal;